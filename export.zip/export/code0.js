gdjs.Untitled_32sceneCode = {};
gdjs.Untitled_32sceneCode.localVariables = [];
gdjs.Untitled_32sceneCode.idToCallbackMap = new Map();
gdjs.Untitled_32sceneCode.forEachIndex2 = 0;

gdjs.Untitled_32sceneCode.forEachObjects2 = [];

gdjs.Untitled_32sceneCode.forEachTemporary2 = null;

gdjs.Untitled_32sceneCode.forEachTotalCount2 = 0;

gdjs.Untitled_32sceneCode.GDPlayerObjects1= [];
gdjs.Untitled_32sceneCode.GDPlayerObjects2= [];
gdjs.Untitled_32sceneCode.GDPlayerObjects3= [];
gdjs.Untitled_32sceneCode.GDPlayerObjects4= [];
gdjs.Untitled_32sceneCode.GDBulletObjects1= [];
gdjs.Untitled_32sceneCode.GDBulletObjects2= [];
gdjs.Untitled_32sceneCode.GDBulletObjects3= [];
gdjs.Untitled_32sceneCode.GDBulletObjects4= [];
gdjs.Untitled_32sceneCode.GDWallObjects1= [];
gdjs.Untitled_32sceneCode.GDWallObjects2= [];
gdjs.Untitled_32sceneCode.GDWallObjects3= [];
gdjs.Untitled_32sceneCode.GDWallObjects4= [];
gdjs.Untitled_32sceneCode.GDEnemyObjects1= [];
gdjs.Untitled_32sceneCode.GDEnemyObjects2= [];
gdjs.Untitled_32sceneCode.GDEnemyObjects3= [];
gdjs.Untitled_32sceneCode.GDEnemyObjects4= [];
gdjs.Untitled_32sceneCode.GDBulletEnemyObjects1= [];
gdjs.Untitled_32sceneCode.GDBulletEnemyObjects2= [];
gdjs.Untitled_32sceneCode.GDBulletEnemyObjects3= [];
gdjs.Untitled_32sceneCode.GDBulletEnemyObjects4= [];
gdjs.Untitled_32sceneCode.GDBoss2Objects1= [];
gdjs.Untitled_32sceneCode.GDBoss2Objects2= [];
gdjs.Untitled_32sceneCode.GDBoss2Objects3= [];
gdjs.Untitled_32sceneCode.GDBoss2Objects4= [];
gdjs.Untitled_32sceneCode.GDLavaObjects1= [];
gdjs.Untitled_32sceneCode.GDLavaObjects2= [];
gdjs.Untitled_32sceneCode.GDLavaObjects3= [];
gdjs.Untitled_32sceneCode.GDLavaObjects4= [];
gdjs.Untitled_32sceneCode.GDbgObjects1= [];
gdjs.Untitled_32sceneCode.GDbgObjects2= [];
gdjs.Untitled_32sceneCode.GDbgObjects3= [];
gdjs.Untitled_32sceneCode.GDbgObjects4= [];
gdjs.Untitled_32sceneCode.GDenemyBarObjects1= [];
gdjs.Untitled_32sceneCode.GDenemyBarObjects2= [];
gdjs.Untitled_32sceneCode.GDenemyBarObjects3= [];
gdjs.Untitled_32sceneCode.GDenemyBarObjects4= [];
gdjs.Untitled_32sceneCode.GDRedFlatBarObjects1= [];
gdjs.Untitled_32sceneCode.GDRedFlatBarObjects2= [];
gdjs.Untitled_32sceneCode.GDRedFlatBarObjects3= [];
gdjs.Untitled_32sceneCode.GDRedFlatBarObjects4= [];


gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDBulletObjects1Objects = Hashtable.newFrom({"Bullet": gdjs.Untitled_32sceneCode.GDBulletObjects1});
gdjs.Untitled_32sceneCode.asyncCallback11836284 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects3);

{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayerObjects3[i].activateBehavior("TopDownMovement", true);
}
}
gdjs.Untitled_32sceneCode.localVariables.length = 0;
}
gdjs.Untitled_32sceneCode.idToCallbackMap.set(11836284, gdjs.Untitled_32sceneCode.asyncCallback11836284);
gdjs.Untitled_32sceneCode.eventsList0 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
for (const obj of gdjs.Untitled_32sceneCode.GDPlayerObjects2) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.Untitled_32sceneCode.asyncCallback11836284(runtimeScene, asyncObjectsList)), 11836284, asyncObjectsList);
}
}

}


};gdjs.Untitled_32sceneCode.asyncCallback16695836 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects2);

{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayerObjects2[i].clearForces();
}
}

{ //Subevents
gdjs.Untitled_32sceneCode.eventsList0(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.Untitled_32sceneCode.localVariables.length = 0;
}
gdjs.Untitled_32sceneCode.idToCallbackMap.set(16695836, gdjs.Untitled_32sceneCode.asyncCallback16695836);
gdjs.Untitled_32sceneCode.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
for (const obj of gdjs.Untitled_32sceneCode.GDPlayerObjects1) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.Untitled_32sceneCode.asyncCallback16695836(runtimeScene, asyncObjectsList)), 16695836, asyncObjectsList);
}
}

}


};gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Untitled_32sceneCode.GDPlayerObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDWallObjects1Objects = Hashtable.newFrom({"Wall": gdjs.Untitled_32sceneCode.GDWallObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDWallObjects1Objects = Hashtable.newFrom({"Wall": gdjs.Untitled_32sceneCode.GDWallObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDWallObjects1Objects = Hashtable.newFrom({"Wall": gdjs.Untitled_32sceneCode.GDWallObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDBulletObjects1Objects = Hashtable.newFrom({"Bullet": gdjs.Untitled_32sceneCode.GDBulletObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDWallObjects1Objects = Hashtable.newFrom({"Wall": gdjs.Untitled_32sceneCode.GDWallObjects1});
gdjs.Untitled_32sceneCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16047476);
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDEnemyObjects2, gdjs.Untitled_32sceneCode.GDEnemyObjects3);

{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDEnemyObjects3[i].getBehavior("Animation").setAnimationIndex(1);
}
}
}

}


{

/* Reuse gdjs.Untitled_32sceneCode.GDEnemyObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDEnemyObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDEnemyObjects2[i].getAnimationFrame() == 6 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDEnemyObjects2[k] = gdjs.Untitled_32sceneCode.GDEnemyObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDEnemyObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDEnemyObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDEnemyObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDEnemyObjects2[i].getBehavior("Tween").addObjectPositionTween2("Charge", (( gdjs.Untitled_32sceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDPlayerObjects2[0].getPointX("")), (( gdjs.Untitled_32sceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDPlayerObjects2[0].getPointY("")), runtimeScene.getGame().getNamedEasingsManager().resolve("easeOutQuad", ""), 0.35, false);
}
}
}

}


};gdjs.Untitled_32sceneCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDEnemyObjects1, gdjs.Untitled_32sceneCode.GDEnemyObjects2);

{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDEnemyObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDEnemyObjects2[i].returnVariable(gdjs.Untitled_32sceneCode.GDEnemyObjects2[i].getVariables().getFromIndex(1)).setBoolean(true);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDEnemyObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDEnemyObjects2[i].resetTimer("Charge");
}
}
}

}


{

gdjs.copyArray(gdjs.Untitled_32sceneCode.GDEnemyObjects1, gdjs.Untitled_32sceneCode.GDEnemyObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDEnemyObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDEnemyObjects2[i].getTimerElapsedTimeInSecondsOrNaN("Charge") > 2 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDEnemyObjects2[k] = gdjs.Untitled_32sceneCode.GDEnemyObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDEnemyObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Untitled_32sceneCode.eventsList2(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.Untitled_32sceneCode.GDEnemyObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDEnemyObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDEnemyObjects1[i].getBehavior("Tween").hasFinished("Charge") ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDEnemyObjects1[k] = gdjs.Untitled_32sceneCode.GDEnemyObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDEnemyObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14563732);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDEnemyObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDEnemyObjects1[i].getBehavior("Animation").setAnimationIndex(0);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDEnemyObjects1[i].resetTimer("Charge");
}
}
}

}


};gdjs.Untitled_32sceneCode.eventsList4 = function(runtimeScene) {

};gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDEnemyObjects2Objects = Hashtable.newFrom({"Enemy": gdjs.Untitled_32sceneCode.GDEnemyObjects2});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDEnemyObjects2Objects = Hashtable.newFrom({"Enemy": gdjs.Untitled_32sceneCode.GDEnemyObjects2});
gdjs.Untitled_32sceneCode.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10411508);
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDEnemyObjects2, gdjs.Untitled_32sceneCode.GDEnemyObjects3);

{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDEnemyObjects3[i].getBehavior("Animation").setAnimationIndex(1);
}
}
}

}


{

/* Reuse gdjs.Untitled_32sceneCode.GDEnemyObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDEnemyObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDEnemyObjects2[i].getAnimationFrame() == 6 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDEnemyObjects2[k] = gdjs.Untitled_32sceneCode.GDEnemyObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDEnemyObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDEnemyObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDEnemyObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDEnemyObjects2[i].getBehavior("Tween").addObjectPositionTween2("Charge", (( gdjs.Untitled_32sceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDPlayerObjects2[0].getPointX("")), (( gdjs.Untitled_32sceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDPlayerObjects2[0].getPointY("")), runtimeScene.getGame().getNamedEasingsManager().resolve("easeOutQuad", ""), 0.35, false);
}
}
}

}


};gdjs.Untitled_32sceneCode.eventsList6 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10227044);
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDEnemyObjects2, gdjs.Untitled_32sceneCode.GDEnemyObjects3);

{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDEnemyObjects3[i].getBehavior("Animation").setAnimationIndex(1);
}
}
}

}


{

/* Reuse gdjs.Untitled_32sceneCode.GDEnemyObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDEnemyObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDEnemyObjects2[i].getAnimationFrame() == 6 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDEnemyObjects2[k] = gdjs.Untitled_32sceneCode.GDEnemyObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDEnemyObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDEnemyObjects2 */
/* Reuse gdjs.Untitled_32sceneCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDEnemyObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDEnemyObjects2[i].getBehavior("Tween").addObjectPositionTween2("Charge", (( gdjs.Untitled_32sceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDPlayerObjects2[0].getPointX("")), (( gdjs.Untitled_32sceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDPlayerObjects2[0].getPointY("")), runtimeScene.getGame().getNamedEasingsManager().resolve("easeOutQuad", ""), 0.35, false);
}
}
}

}


};gdjs.Untitled_32sceneCode.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Untitled_32sceneCode.GDEnemyObjects2, gdjs.Untitled_32sceneCode.GDEnemyObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDEnemyObjects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDEnemyObjects3[i].getBehavior("Tween").hasFinished("Charge") ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDEnemyObjects3[k] = gdjs.Untitled_32sceneCode.GDEnemyObjects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDEnemyObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11950540);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDEnemyObjects3 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDEnemyObjects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDEnemyObjects3[i].resetTimer("Charge");
}
}
}

}


};gdjs.Untitled_32sceneCode.eventsList8 = function(runtimeScene) {

{


const repeatCount3 = 2;
for (let repeatIndex3 = 0;repeatIndex3 < repeatCount3;++repeatIndex3) {

let isConditionTrue_0 = false;
if (true)
{
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12024468);
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDEnemyObjects1, gdjs.Untitled_32sceneCode.GDEnemyObjects2);

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDEnemyObjects2Objects, (( gdjs.Untitled_32sceneCode.GDEnemyObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDEnemyObjects2[0].getPointX("l")), (( gdjs.Untitled_32sceneCode.GDEnemyObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDEnemyObjects2[0].getPointY("l")), "");
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDEnemyObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDEnemyObjects2[i].returnVariable(gdjs.Untitled_32sceneCode.GDEnemyObjects2[i].getVariables().getFromIndex(0)).setNumber(2);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDEnemyObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDEnemyObjects2[i].resetTimer("Charge");
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDEnemyObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDEnemyObjects2[i].returnVariable(gdjs.Untitled_32sceneCode.GDEnemyObjects2[i].getVariables().getFromIndex(2)).setNumber(1);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDEnemyObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDEnemyObjects2[i].getBehavior("Scale").setScale(0.75);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16355180);
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDEnemyObjects1, gdjs.Untitled_32sceneCode.GDEnemyObjects2);

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDEnemyObjects2Objects, (( gdjs.Untitled_32sceneCode.GDEnemyObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDEnemyObjects2[0].getPointX("r")), (( gdjs.Untitled_32sceneCode.GDEnemyObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDEnemyObjects2[0].getPointY("r")), "");
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDEnemyObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDEnemyObjects2[i].returnVariable(gdjs.Untitled_32sceneCode.GDEnemyObjects2[i].getVariables().getFromIndex(0)).setNumber(2);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDEnemyObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDEnemyObjects2[i].returnVariable(gdjs.Untitled_32sceneCode.GDEnemyObjects2[i].getVariables().getFromIndex(2)).setNumber(2);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDEnemyObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDEnemyObjects2[i].resetTimer("Charge");
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDEnemyObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDEnemyObjects2[i].getBehavior("Scale").setScale(0.75);
}
}
}

}


{

gdjs.copyArray(gdjs.Untitled_32sceneCode.GDEnemyObjects1, gdjs.Untitled_32sceneCode.GDEnemyObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDEnemyObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDEnemyObjects2[i].getVariableBoolean(gdjs.Untitled_32sceneCode.GDEnemyObjects2[i].getVariables().getFromIndex(1), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDEnemyObjects2[k] = gdjs.Untitled_32sceneCode.GDEnemyObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDEnemyObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDEnemyObjects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDEnemyObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDEnemyObjects2[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(gdjs.Untitled_32sceneCode.GDEnemyObjects1, gdjs.Untitled_32sceneCode.GDEnemyObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDEnemyObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDEnemyObjects2[i].getTimerElapsedTimeInSecondsOrNaN("Charge") > 2 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDEnemyObjects2[k] = gdjs.Untitled_32sceneCode.GDEnemyObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDEnemyObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDEnemyObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDEnemyObjects2[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDEnemyObjects2[i].getVariables().getFromIndex(2)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDEnemyObjects2[k] = gdjs.Untitled_32sceneCode.GDEnemyObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDEnemyObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14751460);
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Untitled_32sceneCode.eventsList5(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Untitled_32sceneCode.GDEnemyObjects1, gdjs.Untitled_32sceneCode.GDEnemyObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDEnemyObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDEnemyObjects2[i].getTimerElapsedTimeInSecondsOrNaN("Charge") > 2 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDEnemyObjects2[k] = gdjs.Untitled_32sceneCode.GDEnemyObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDEnemyObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDEnemyObjects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDEnemyObjects2[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDEnemyObjects2[i].getVariables().getFromIndex(2)) == 2 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDEnemyObjects2[k] = gdjs.Untitled_32sceneCode.GDEnemyObjects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDEnemyObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16473420);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDEnemyObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDEnemyObjects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDEnemyObjects2[i].getBehavior("Tween").addObjectPositionTween2("Charge", (( gdjs.Untitled_32sceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDPlayerObjects2[0].getPointX("")) - gdjs.randomInRange(0, 50), (( gdjs.Untitled_32sceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDPlayerObjects2[0].getPointY("")) - gdjs.randomInRange(0, 50), runtimeScene.getGame().getNamedEasingsManager().resolve("easeOutQuad", ""), 0.8, false);
}
}

{ //Subevents
gdjs.Untitled_32sceneCode.eventsList6(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.Untitled_32sceneCode.GDEnemyObjects1 */

for (gdjs.Untitled_32sceneCode.forEachIndex2 = 0;gdjs.Untitled_32sceneCode.forEachIndex2 < gdjs.Untitled_32sceneCode.GDEnemyObjects1.length;++gdjs.Untitled_32sceneCode.forEachIndex2) {
gdjs.Untitled_32sceneCode.GDEnemyObjects2.length = 0;


gdjs.Untitled_32sceneCode.forEachTemporary2 = gdjs.Untitled_32sceneCode.GDEnemyObjects1[gdjs.Untitled_32sceneCode.forEachIndex2];
gdjs.Untitled_32sceneCode.GDEnemyObjects2.push(gdjs.Untitled_32sceneCode.forEachTemporary2);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.Untitled_32sceneCode.eventsList7(runtimeScene);} //Subevents end.
}
}

}


};gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDBulletEnemyObjects2Objects = Hashtable.newFrom({"BulletEnemy": gdjs.Untitled_32sceneCode.GDBulletEnemyObjects2});
gdjs.Untitled_32sceneCode.eventsList9 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13649692);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDBoss2Objects2 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBoss2Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBoss2Objects2[i].getBehavior("Tween").addObjectPositionTween2("Centre", 320, 180, runtimeScene.getGame().getNamedEasingsManager().resolve("easeOutQuad", ""), 1, false);
}
}
}

}


};gdjs.Untitled_32sceneCode.eventsList10 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13773908);
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDBoss2Objects1, gdjs.Untitled_32sceneCode.GDBoss2Objects2);

{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBoss2Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBoss2Objects2[i].resetTimer("SHoot");
}
}
}

}


{

gdjs.copyArray(gdjs.Untitled_32sceneCode.GDBoss2Objects1, gdjs.Untitled_32sceneCode.GDBoss2Objects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDBoss2Objects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDBoss2Objects2[i].getTimerElapsedTimeInSecondsOrNaN("SHoot") < 6 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDBoss2Objects2[k] = gdjs.Untitled_32sceneCode.GDBoss2Objects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDBoss2Objects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDBoss2Objects2 */
gdjs.Untitled_32sceneCode.GDBulletEnemyObjects2.length = 0;

{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBoss2Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBoss2Objects2[i].getBehavior("FireBullet").Fire((gdjs.Untitled_32sceneCode.GDBoss2Objects2[i].getPointX("")), (gdjs.Untitled_32sceneCode.GDBoss2Objects2[i].getPointY("")), gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDBulletEnemyObjects2Objects, 0, 300, null);
}
}

{ //Subevents
gdjs.Untitled_32sceneCode.eventsList9(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Untitled_32sceneCode.GDBoss2Objects1, gdjs.Untitled_32sceneCode.GDBoss2Objects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDBoss2Objects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDBoss2Objects2[i].getTimerElapsedTimeInSecondsOrNaN("SHoot") >= 6 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDBoss2Objects2[k] = gdjs.Untitled_32sceneCode.GDBoss2Objects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDBoss2Objects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDBoss2Objects2 */
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBoss2Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBoss2Objects2[i].addForceTowardObject((gdjs.Untitled_32sceneCode.GDPlayerObjects2.length !== 0 ? gdjs.Untitled_32sceneCode.GDPlayerObjects2[0] : null), 130, 0);
}
}
}

}


{

/* Reuse gdjs.Untitled_32sceneCode.GDBoss2Objects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDBoss2Objects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDBoss2Objects1[i].getTimerElapsedTimeInSecondsOrNaN("SHoot") >= 13 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDBoss2Objects1[k] = gdjs.Untitled_32sceneCode.GDBoss2Objects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDBoss2Objects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDBoss2Objects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBoss2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBoss2Objects1[i].resetTimer("SHoot");
}
}
}

}


};gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDLavaObjects2Objects = Hashtable.newFrom({"Lava": gdjs.Untitled_32sceneCode.GDLavaObjects2});
gdjs.Untitled_32sceneCode.eventsList11 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11704412);
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDBoss2Objects2, gdjs.Untitled_32sceneCode.GDBoss2Objects3);

{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBoss2Objects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBoss2Objects3[i].getBehavior("Tween").addObjectPositionTween2("Centre", 320, 180, runtimeScene.getGame().getNamedEasingsManager().resolve("easeOutQuad", ""), 1, false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBoss2Objects3.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBoss2Objects3[i].resetTimer("LavaSpawn");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDPlayerObjects3[i].getBehavior("TopDownMovement").getXVelocity() > 0 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDPlayerObjects3[k] = gdjs.Untitled_32sceneCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDPlayerObjects3[i].getBehavior("TopDownMovement").getXVelocity() < 0 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDPlayerObjects3[k] = gdjs.Untitled_32sceneCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(-1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDPlayerObjects3[i].getBehavior("TopDownMovement").getXVelocity() < 0 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDPlayerObjects3[k] = gdjs.Untitled_32sceneCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(-1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDPlayerObjects3[i].getBehavior("TopDownMovement").getYVelocity() > 0 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDPlayerObjects3[k] = gdjs.Untitled_32sceneCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDPlayerObjects3[i].getBehavior("TopDownMovement").getYVelocity() < 0 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDPlayerObjects3[k] = gdjs.Untitled_32sceneCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(-1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDPlayerObjects3[i].getBehavior("TopDownMovement").getYVelocity() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDPlayerObjects3[k] = gdjs.Untitled_32sceneCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(0);
}
}

}


{

/* Reuse gdjs.Untitled_32sceneCode.GDBoss2Objects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDBoss2Objects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDBoss2Objects2[i].getTimerElapsedTimeInSecondsOrNaN("LavaSpawn") > 1.5 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDBoss2Objects2[k] = gdjs.Untitled_32sceneCode.GDBoss2Objects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDBoss2Objects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDBoss2Objects2 */
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects2);
gdjs.Untitled_32sceneCode.GDLavaObjects2.length = 0;

{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBoss2Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBoss2Objects2[i].resetTimer("LavaSpawn");
}
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDLavaObjects2Objects, (( gdjs.Untitled_32sceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDPlayerObjects2[0].getPointX("")) + (64 * runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber()), (( gdjs.Untitled_32sceneCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDPlayerObjects2[0].getPointY("")) + (64 * runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber()), "");
}
}

}


};gdjs.Untitled_32sceneCode.eventsList12 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16957988);
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Untitled_32sceneCode.GDBoss2Objects1, gdjs.Untitled_32sceneCode.GDBoss2Objects2);

{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBoss2Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBoss2Objects2[i].resetTimer("Lava");
}
}
}

}


{

gdjs.copyArray(gdjs.Untitled_32sceneCode.GDBoss2Objects1, gdjs.Untitled_32sceneCode.GDBoss2Objects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDBoss2Objects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDBoss2Objects2[i].getTimerElapsedTimeInSecondsOrNaN("Lava") < 10 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDBoss2Objects2[k] = gdjs.Untitled_32sceneCode.GDBoss2Objects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDBoss2Objects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Untitled_32sceneCode.eventsList11(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Untitled_32sceneCode.GDBoss2Objects1, gdjs.Untitled_32sceneCode.GDBoss2Objects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDBoss2Objects2.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDBoss2Objects2[i].getTimerElapsedTimeInSecondsOrNaN("Lava") >= 10 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDBoss2Objects2[k] = gdjs.Untitled_32sceneCode.GDBoss2Objects2[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDBoss2Objects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDBoss2Objects2 */
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBoss2Objects2.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBoss2Objects2[i].addForceTowardObject((gdjs.Untitled_32sceneCode.GDPlayerObjects2.length !== 0 ? gdjs.Untitled_32sceneCode.GDPlayerObjects2[0] : null), 130, 0);
}
}
}

}


{

/* Reuse gdjs.Untitled_32sceneCode.GDBoss2Objects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDBoss2Objects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDBoss2Objects1[i].getTimerElapsedTimeInSecondsOrNaN("Lava") >= 18 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDBoss2Objects1[k] = gdjs.Untitled_32sceneCode.GDBoss2Objects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDBoss2Objects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDBoss2Objects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBoss2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBoss2Objects1[i].resetTimer("Lava");
}
}
}

}


};gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDEnemyObjects1Objects = Hashtable.newFrom({"Enemy": gdjs.Untitled_32sceneCode.GDEnemyObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDWallObjects1Objects = Hashtable.newFrom({"Wall": gdjs.Untitled_32sceneCode.GDWallObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDWallObjects1Objects = Hashtable.newFrom({"Wall": gdjs.Untitled_32sceneCode.GDWallObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDBulletObjects1Objects = Hashtable.newFrom({"Bullet": gdjs.Untitled_32sceneCode.GDBulletObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDEnemyObjects1Objects = Hashtable.newFrom({"Enemy": gdjs.Untitled_32sceneCode.GDEnemyObjects1});
gdjs.Untitled_32sceneCode.eventsList13 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects1);
gdjs.Untitled_32sceneCode.GDBulletObjects1.length = 0;

{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayerObjects1[i].getBehavior("FireBullet").FireTowardPosition((gdjs.Untitled_32sceneCode.GDPlayerObjects1[i].getPointX("")), (gdjs.Untitled_32sceneCode.GDPlayerObjects1[i].getPointY("")), gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDBulletObjects1Objects, gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), 400, null);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12032340);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayerObjects1[i].activateBehavior("TopDownMovement", false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayerObjects1[i].addPolarForce(gdjs.evtTools.common.angleBetweenPositions((gdjs.Untitled_32sceneCode.GDPlayerObjects1[i].getPointX("")), (gdjs.Untitled_32sceneCode.GDPlayerObjects1[i].getPointY("")), gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0)), 150 / 0.2, 1);
}
}

{ //Subevents
gdjs.Untitled_32sceneCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDPlayerObjects1[i].getBehavior("FireBullet").HasJustFired(null) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDPlayerObjects1[k] = gdjs.Untitled_32sceneCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.2, 0, 0, null);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Wall"), gdjs.Untitled_32sceneCode.GDWallObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayerObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDWallObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDPlayerObjects1 */
/* Reuse gdjs.Untitled_32sceneCode.GDWallObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayerObjects1[i].separateFromObjectsList(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDWallObjects1Objects, false);
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Untitled_32sceneCode.GDBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("Wall"), gdjs.Untitled_32sceneCode.GDWallObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBulletObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBulletObjects1[i].getBehavior("Bounce").BounceOff(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDWallObjects1Objects, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Untitled_32sceneCode.GDBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("Wall"), gdjs.Untitled_32sceneCode.GDWallObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDBulletObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDWallObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9676788);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDBulletObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBulletObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBulletObjects1[i].returnVariable(gdjs.Untitled_32sceneCode.GDBulletObjects1[i].getVariables().getFromIndex(0)).add(1);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Untitled_32sceneCode.GDBulletObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDBulletObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDBulletObjects1[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDBulletObjects1[i].getVariables().getFromIndex(0)) >= 2 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDBulletObjects1[k] = gdjs.Untitled_32sceneCode.GDBulletObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDBulletObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDBulletObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBulletObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBulletObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "f");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16478316);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Boss2"), gdjs.Untitled_32sceneCode.GDBoss2Objects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBoss2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBoss2Objects1[i].returnVariable(gdjs.Untitled_32sceneCode.GDBoss2Objects1[i].getVariables().getFromIndex(0)).add(1);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.Untitled_32sceneCode.GDEnemyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDEnemyObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDEnemyObjects1[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDEnemyObjects1[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDEnemyObjects1[k] = gdjs.Untitled_32sceneCode.GDEnemyObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDEnemyObjects1.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Untitled_32sceneCode.eventsList3(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.Untitled_32sceneCode.GDEnemyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDEnemyObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDEnemyObjects1[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDEnemyObjects1[i].getVariables().getFromIndex(0)) == 2 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDEnemyObjects1[k] = gdjs.Untitled_32sceneCode.GDEnemyObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDEnemyObjects1.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Untitled_32sceneCode.eventsList8(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Boss2"), gdjs.Untitled_32sceneCode.GDBoss2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDBoss2Objects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDBoss2Objects1[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDBoss2Objects1[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDBoss2Objects1[k] = gdjs.Untitled_32sceneCode.GDBoss2Objects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDBoss2Objects1.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Untitled_32sceneCode.eventsList10(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Boss2"), gdjs.Untitled_32sceneCode.GDBoss2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDBoss2Objects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDBoss2Objects1[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDBoss2Objects1[i].getVariables().getFromIndex(0)) == 2 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDBoss2Objects1[k] = gdjs.Untitled_32sceneCode.GDBoss2Objects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDBoss2Objects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDBoss2Objects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBoss2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBoss2Objects1[i].removeTimer("SHoot");
}
}

{ //Subevents
gdjs.Untitled_32sceneCode.eventsList12(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.Untitled_32sceneCode.GDEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("Wall"), gdjs.Untitled_32sceneCode.GDWallObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDEnemyObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDWallObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDEnemyObjects1 */
/* Reuse gdjs.Untitled_32sceneCode.GDWallObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDEnemyObjects1[i].separateFromObjectsList(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDWallObjects1Objects, false);
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Wall"), gdjs.Untitled_32sceneCode.GDWallObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDWallObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDWallObjects1[i].hide();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) < (( gdjs.Untitled_32sceneCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDPlayerObjects1[0].getPointX(""));
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayerObjects1[i].getBehavior("Flippable").flipX(true);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) >= (( gdjs.Untitled_32sceneCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDPlayerObjects1[0].getPointX(""));
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayerObjects1[i].getBehavior("Flippable").flipX(false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.Untitled_32sceneCode.GDEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDEnemyObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDEnemyObjects1[i].getX() < (( gdjs.Untitled_32sceneCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDPlayerObjects1[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDEnemyObjects1[k] = gdjs.Untitled_32sceneCode.GDEnemyObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDEnemyObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDEnemyObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDEnemyObjects1[i].getBehavior("Flippable").flipX(true);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.Untitled_32sceneCode.GDEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Untitled_32sceneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDEnemyObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDEnemyObjects1[i].getX() >= (( gdjs.Untitled_32sceneCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDPlayerObjects1[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDEnemyObjects1[k] = gdjs.Untitled_32sceneCode.GDEnemyObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDEnemyObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDEnemyObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDEnemyObjects1[i].getBehavior("Flippable").flipX(false);
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.Untitled_32sceneCode.GDEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("enemyBar"), gdjs.Untitled_32sceneCode.GDenemyBarObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDenemyBarObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDenemyBarObjects1[i].SetValue((( gdjs.Untitled_32sceneCode.GDEnemyObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDEnemyObjects1[0].getBehavior("Health").Health(null)), null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.Untitled_32sceneCode.GDBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.Untitled_32sceneCode.GDEnemyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDBulletObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDEnemyObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDEnemyObjects1.length;i<l;++i) {
    if ( !(gdjs.Untitled_32sceneCode.GDEnemyObjects1[i].getBehavior("Flash").IsFlashing(null)) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDEnemyObjects1[k] = gdjs.Untitled_32sceneCode.GDEnemyObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDEnemyObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDBulletObjects1 */
/* Reuse gdjs.Untitled_32sceneCode.GDEnemyObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDEnemyObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.3, 5, 5, 5, 0.08, false, null);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDEnemyObjects1[i].getBehavior("Flash").Flash(0.5, null);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBulletObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBulletObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDEnemyObjects1[i].getBehavior("Health").Hit(2, true, true, null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy"), gdjs.Untitled_32sceneCode.GDEnemyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDEnemyObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDEnemyObjects1[i].getBehavior("Health").Health(null) == 50 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDEnemyObjects1[k] = gdjs.Untitled_32sceneCode.GDEnemyObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDEnemyObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDEnemyObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDEnemyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDEnemyObjects1[i].returnVariable(gdjs.Untitled_32sceneCode.GDEnemyObjects1[i].getVariables().getFromIndex(0)).setNumber(2);
}
}
}

}


};

gdjs.Untitled_32sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Untitled_32sceneCode.GDPlayerObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDPlayerObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDPlayerObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDPlayerObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDBulletObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBulletObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBulletObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDBulletObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDWallObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDWallObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDWallObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDWallObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDEnemyObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDEnemyObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDEnemyObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDEnemyObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDBulletEnemyObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBulletEnemyObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBulletEnemyObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDBulletEnemyObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDBoss2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDBoss2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDBoss2Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDBoss2Objects4.length = 0;
gdjs.Untitled_32sceneCode.GDLavaObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDLavaObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDLavaObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDLavaObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDbgObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDbgObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDbgObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDbgObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDenemyBarObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDenemyBarObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDenemyBarObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDenemyBarObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDRedFlatBarObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDRedFlatBarObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDRedFlatBarObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDRedFlatBarObjects4.length = 0;

gdjs.Untitled_32sceneCode.eventsList13(runtimeScene);
gdjs.Untitled_32sceneCode.GDPlayerObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDPlayerObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDPlayerObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDPlayerObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDBulletObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBulletObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBulletObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDBulletObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDWallObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDWallObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDWallObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDWallObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDEnemyObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDEnemyObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDEnemyObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDEnemyObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDBulletEnemyObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBulletEnemyObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBulletEnemyObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDBulletEnemyObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDBoss2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDBoss2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDBoss2Objects3.length = 0;
gdjs.Untitled_32sceneCode.GDBoss2Objects4.length = 0;
gdjs.Untitled_32sceneCode.GDLavaObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDLavaObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDLavaObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDLavaObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDbgObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDbgObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDbgObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDbgObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDenemyBarObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDenemyBarObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDenemyBarObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDenemyBarObjects4.length = 0;
gdjs.Untitled_32sceneCode.GDRedFlatBarObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDRedFlatBarObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDRedFlatBarObjects3.length = 0;
gdjs.Untitled_32sceneCode.GDRedFlatBarObjects4.length = 0;


return;

}

gdjs['Untitled_32sceneCode'] = gdjs.Untitled_32sceneCode;
